export function randomUUID() {
  if (globalThis.crypto.randomUUID) return globalThis.crypto.randomUUID();
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function unsupported() {
  throw Object.assign(new Error('Online accounts are unavailable in this browser-only demo. Play as a guest; your farm saves on this device.'), {
    code: 'LOCAL_UNAVAILABLE', status: 501,
  });
}
export const scryptSync = unsupported;
export const timingSafeEqual = unsupported;
