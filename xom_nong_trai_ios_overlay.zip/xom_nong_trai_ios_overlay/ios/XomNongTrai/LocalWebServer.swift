import Foundation
import Network

/// Máy chủ HTTP rất nhỏ chạy trong app, chỉ lắng nghe 127.0.0.1.
/// Cần thiết vì game dùng navigator.locks + localStorage (yêu cầu "secure context"),
/// và http://127.0.0.1 được WebKit coi là secure context. Có hỗ trợ Range cho file mp3.
final class LocalWebServer {
    static let portNumber: UInt16 = 38765
    static var baseURL: URL { URL(string: "http://127.0.0.1:\(portNumber)/")! }

    private let root: URL
    private var listener: NWListener?
    private let queue = DispatchQueue(label: "xnt.localwebserver", qos: .userInitiated)
    private(set) var isReady = false

    init(root: URL) { self.root = root }

    func start(completion: @escaping (Bool) -> Void) {
        stop()
        guard let port = NWEndpoint.Port(rawValue: Self.portNumber) else { completion(false); return }
        let params = NWParameters.tcp
        params.requiredInterfaceType = .loopback
        params.allowLocalEndpointReuse = true
        let l: NWListener
        do { l = try NWListener(using: params, on: port) } catch { completion(false); return }
        var reported = false
        l.stateUpdateHandler = { [weak self] state in
            switch state {
            case .ready:
                self?.isReady = true
                if !reported { reported = true; DispatchQueue.main.async { completion(true) } }
            case .failed, .cancelled:
                self?.isReady = false
                if !reported { reported = true; DispatchQueue.main.async { completion(false) } }
            default: break
            }
        }
        l.newConnectionHandler = { [weak self] conn in self?.accept(conn) }
        listener = l
        l.start(queue: queue)
    }

    func stop() {
        listener?.cancel()
        listener = nil
        isReady = false
    }

    // MARK: - Kết nối

    private func accept(_ conn: NWConnection) {
        conn.start(queue: queue)
        readHead(conn, buffer: Data())
    }

    private func readHead(_ conn: NWConnection, buffer: Data) {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 16384) { [weak self] data, _, isComplete, error in
            guard let self = self else { conn.cancel(); return }
            var buf = buffer
            if let data = data { buf.append(data) }
            if let end = buf.range(of: Data("\r\n\r\n".utf8)) {
                self.respond(conn, head: buf.subdata(in: 0..<end.lowerBound))
            } else if error != nil || isComplete || buf.count > 65536 {
                conn.cancel()
            } else {
                self.readHead(conn, buffer: buf)
            }
        }
    }

    private func respond(_ conn: NWConnection, head: Data) {
        guard let text = String(data: head, encoding: .utf8) else {
            return send(conn, status: "400 Bad Request", headers: [:], body: Data())
        }
        let lines = text.components(separatedBy: "\r\n")
        let first = lines[0].split(separator: " ")
        guard first.count >= 2 else {
            return send(conn, status: "400 Bad Request", headers: [:], body: Data())
        }
        let method = String(first[0])
        guard method == "GET" || method == "HEAD" else {
            return send(conn, status: "405 Method Not Allowed", headers: ["Allow": "GET, HEAD"], body: Data())
        }
        var rangeHeader: String?
        for line in lines.dropFirst() where line.lowercased().hasPrefix("range:") {
            rangeHeader = String(line.dropFirst(6)).trimmingCharacters(in: .whitespaces)
        }

        var path = String(first[1])
        if let cut = path.firstIndex(where: { $0 == "?" || $0 == "#" }) { path = String(path[..<cut]) }
        path = path.removingPercentEncoding ?? path

        guard let file = resolve(path),
              let data = try? Data(contentsOf: file, options: .mappedIfSafe) else {
            return send(conn, status: "404 Not Found", headers: ["Content-Type": "text/plain; charset=utf-8"],
                        body: Data("Not found".utf8), head: method == "HEAD")
        }

        let total = data.count
        var headers: [String: String] = [
            "Content-Type": Self.mime(for: file.pathExtension),
            "Accept-Ranges": "bytes",
            "Cache-Control": "no-cache",
        ]

        if let rangeHeader = rangeHeader, rangeHeader.lowercased().hasPrefix("bytes=") {
            let spec = rangeHeader.dropFirst(6).split(separator: ",").first.map(String.init) ?? ""
            let bounds = spec.split(separator: "-", maxSplits: 1, omittingEmptySubsequences: false).map { String($0).trimmingCharacters(in: .whitespaces) }
            var start = 0
            var end = total - 1
            var valid = bounds.count == 2
            if valid {
                if bounds[0].isEmpty, let suffix = Int(bounds[1]), suffix > 0 {
                    start = max(0, total - suffix)
                } else if let s = Int(bounds[0]) {
                    start = s
                    if let e = Int(bounds[1]) { end = min(e, total - 1) }
                } else { valid = false }
            }
            if !valid || start > end || start >= total {
                headers["Content-Range"] = "bytes */\(total)"
                return send(conn, status: "416 Range Not Satisfiable", headers: headers, body: Data())
            }
            headers["Content-Range"] = "bytes \(start)-\(end)/\(total)"
            let slice = data.subdata(in: start..<(end + 1))
            return send(conn, status: "206 Partial Content", headers: headers, body: slice, head: method == "HEAD")
        }

        send(conn, status: "200 OK", headers: headers, body: data, head: method == "HEAD")
    }

    private func send(_ conn: NWConnection, status: String, headers: [String: String], body: Data, head: Bool = false) {
        var h = headers
        h["Content-Length"] = String(body.count)
        h["Connection"] = "close"
        var out = "HTTP/1.1 \(status)\r\n"
        for (k, v) in h { out += "\(k): \(v)\r\n" }
        out += "\r\n"
        var payload = Data(out.utf8)
        if !head { payload.append(body) }
        conn.send(content: payload, completion: .contentProcessed { _ in conn.cancel() })
    }

    // MARK: - File

    private func resolve(_ requestPath: String) -> URL? {
        let parts = requestPath.split(separator: "/").map(String.init)
        if parts.contains("..") || parts.contains(where: { $0.contains("\0") }) { return nil }
        var url = root
        for p in parts { url.appendPathComponent(p) }
        var isDir: ObjCBool = false
        if FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir) {
            if isDir.boolValue {
                let index = url.appendingPathComponent("index.html")
                return FileManager.default.fileExists(atPath: index.path) ? index : nil
            }
            return url
        }
        // Đường dẫn kiểu SPA (không có đuôi file) -> index.html
        if let last = parts.last, last.contains(".") { return nil }
        let index = root.appendingPathComponent("index.html")
        return FileManager.default.fileExists(atPath: index.path) ? index : nil
    }

    private static func mime(for ext: String) -> String {
        switch ext.lowercased() {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json", "webmanifest": return "application/json; charset=utf-8"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "webp": return "image/webp"
        case "svg": return "image/svg+xml"
        case "glb": return "model/gltf-binary"
        case "mp3": return "audio/mpeg"
        case "woff2": return "font/woff2"
        case "woff": return "font/woff"
        case "wasm": return "application/wasm"
        case "txt": return "text/plain; charset=utf-8"
        default: return "application/octet-stream"
        }
    }
}
