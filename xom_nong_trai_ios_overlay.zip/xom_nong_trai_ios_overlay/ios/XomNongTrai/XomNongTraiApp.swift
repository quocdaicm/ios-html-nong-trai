import SwiftUI
import AVFoundation

@MainActor
final class ServerHost: ObservableObject {
    enum State { case loading, ready, failed }

    @Published var state: State = .loading
    @Published var reloadToken = 0

    private let server: LocalWebServer?

    init() {
        let web = Bundle.main.resourceURL?.appendingPathComponent("Web")
        if let web = web, FileManager.default.fileExists(atPath: web.appendingPathComponent("index.html").path) {
            server = LocalWebServer(root: web)
        } else {
            server = nil
        }
    }

    func start() {
        try? AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
        try? AVAudioSession.sharedInstance().setActive(true)
        guard let server = server else { state = .failed; return }
        server.start { [weak self] ok in
            self?.state = ok ? .ready : .failed
        }
    }

    /// iOS có thể đóng socket khi app bị tạm dừng; mở lại thì dựng lại server và nạp lại game.
    func ensureRunning() {
        guard let server = server, state != .loading, !server.isReady else { return }
        state = .loading
        server.start { [weak self] ok in
            guard let self = self else { return }
            self.state = ok ? .ready : .failed
            if ok { self.reloadToken += 1 }
        }
    }
}

@main
struct XomNongTraiApp: App {
    @StateObject private var host = ServerHost()
    @Environment(\.scenePhase) private var scenePhase

    private let background = Color(red: 0.98, green: 0.93, blue: 0.80)

    var body: some Scene {
        WindowGroup {
            ZStack {
                background.ignoresSafeArea()
                switch host.state {
                case .ready:
                    GameWebView(url: LocalWebServer.baseURL, reloadToken: host.reloadToken)
                        .ignoresSafeArea()
                case .loading:
                    ProgressView()
                case .failed:
                    VStack(spacing: 12) {
                        Text("Xóm Nông Trại").font(.title2.bold())
                        Text("Không mở được trò chơi. Hãy đóng hẳn app rồi mở lại.")
                            .multilineTextAlignment(.center)
                        Button("Thử lại") { host.start() }
                    }
                    .padding(32)
                    .foregroundColor(Color(red: 0.31, green: 0.20, blue: 0.08))
                }
            }
            .onAppear { host.start() }
            .onChange(of: scenePhase) { phase in
                if phase == .active { host.ensureRunning() }
            }
        }
    }
}
