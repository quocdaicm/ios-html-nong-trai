# Xóm Nông Trại — bản iOS

App SwiftUI bọc bản web của game (WKWebView). Toàn bộ game nằm trong app, chạy offline;
app mở một máy chủ HTTP nhỏ chỉ ở `127.0.0.1:38765` để game có "secure context"
(cần cho `navigator.locks` và localStorage). Tiến trình nông trại lưu trong bộ nhớ của WebView.

## Build trên GitHub (không cần Mac)
1. Đẩy thư mục `ios/` và `.github/workflows/ios.yml` lên nhánh `main`.
2. Vào tab **Actions** → **Build iOS (unsigned IPA)** → **Run workflow**.
3. Khi chạy xong, tải artifact `XomNongTrai-unsigned-ipa` (file `.ipa` chưa ký).

## Cài lên iPhone
File `.ipa` chưa ký nên cần ký lại khi cài: AltStore / SideStore / Sideloadly (Apple ID miễn phí,
hết hạn sau 7 ngày) hoặc TrollStore. Muốn lên TestFlight/App Store cần tài khoản Apple Developer
và chứng chỉ ký.
