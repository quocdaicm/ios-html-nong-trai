import numpy as np, sys, os, json, math, glob
from PIL import Image
name=sys.argv[1]; d=f'Models/{name}'; YAW=float(sys.argv[2]); OUT=sys.argv[3]; PXCM=float(sys.argv[4])
def find(fn):
    fn=os.path.basename(fn.replace('\\','/'))
    for p in os.listdir(d):
        if p.lower()==fn.lower(): return os.path.join(d,p)
mats={'':{'kd':(.6,.6,.6),'tex':None}}
cur=None
for l in open(glob.glob(d+'/*.mtl')[0],errors='ignore'):
    p=l.split()
    if not p: continue
    if p[0]=='newmtl': cur=mats.setdefault(' '.join(p[1:]),{'kd':(.6,.6,.6),'tex':None})
    elif cur is not None and p[0]=='Kd': cur['kd']=tuple(map(float,p[1:4]))
    elif cur is not None and p[0]=='map_Kd':
        fp=find(l.split(None,1)[1].strip().split()[-1])
        if fp: cur['tex']=np.array(Image.open(fp).convert('RGBA'))
V=[];T=[];tris=[];m=''
for l in open(glob.glob(d+'/*.obj')[0],errors='ignore'):
    p=l.split()
    if not p: continue
    if p[0]=='v': V.append(list(map(float,p[1:4])))
    elif p[0]=='vt': T.append([float(p[1]),float(p[2])])
    elif p[0]=='usemtl': m=' '.join(p[1:])
    elif p[0]=='f':
        idx=[]
        for t in p[1:]:
            a=t.split('/');vi=int(a[0]);vi=vi-1 if vi>0 else len(V)+vi
            ti=-1
            if len(a)>1 and a[1]:
                ti=int(a[1]);ti=ti-1 if ti>0 else len(T)+ti
            idx.append((vi,ti))
        for k in range(1,len(idx)-1): tris.append((idx[0],idx[k],idx[k+1],m))
V=np.array(V);T=np.array(T) if T else np.zeros((1,2))
V=V-[ (V[:,0].min()+V[:,0].max())/2, V[:,1].min(), (V[:,2].min()+V[:,2].max())/2 ]
hm=float(V[:,1].max()); 
a=math.radians(YAW);pc=math.radians(30)
x1=V[:,0]*math.cos(a)+V[:,2]*math.sin(a); z1=-V[:,0]*math.sin(a)+V[:,2]*math.cos(a)
sx=x1; sy=-(V[:,1]*math.cos(pc)-z1*math.sin(pc)); dp=-V[:,1]*math.sin(pc)-z1*math.cos(pc)
R=640
sc=PXCM*2
PX=sx*sc+R/2; PY=sy*sc+R*.8
img=np.zeros((R,R,4),np.float32);zb=np.full((R,R),1e9)
Lv=np.array([.5,.8,.4]);Lv/=np.linalg.norm(Lv)
for (a0,t0),(a1,t1),(a2,t2),mn in tris:
    xs=PX[[a0,a1,a2]];ys=PY[[a0,a1,a2]]
    x0,x9=int(max(0,np.floor(xs.min()))),int(min(R-1,np.ceil(xs.max())));y0,y9=int(max(0,np.floor(ys.min()))),int(min(R-1,np.ceil(ys.max())))
    if x9<x0 or y9<y0: continue
    den=(ys[1]-ys[2])*(xs[0]-xs[2])+(xs[2]-xs[1])*(ys[0]-ys[2])
    if abs(den)<1e-9: continue
    gx,gy=np.meshgrid(np.arange(x0,x9+1)+.5,np.arange(y0,y9+1)+.5)
    w0=((ys[1]-ys[2])*(gx-xs[2])+(xs[2]-xs[1])*(gy-ys[2]))/den
    w1=((ys[2]-ys[0])*(gx-xs[2])+(xs[0]-xs[2])*(gy-ys[2]))/den
    w2=1-w0-w1
    ins=(w0>=-1e-4)&(w1>=-1e-4)&(w2>=-1e-4)
    if not ins.any(): continue
    z=w0*dp[a0]+w1*dp[a1]+w2*dp[a2]
    mt=mats.get(mn,mats['']);col=np.empty(gx.shape+(4,),np.float32);col[...]=list(mt['kd'])+[1]
    if mt['tex'] is not None and t0>=0:
        u=w0*T[t0][0]+w1*T[t1][0]+w2*T[t2][0];v=w0*T[t0][1]+w1*T[t1][1]+w2*T[t2][1]
        tx=mt['tex'];h,w=tx.shape[:2]
        col=tx[((1-v)*h).astype(int)%h,(u*w).astype(int)%w].astype(np.float32)/255
    P=V[[a0,a1,a2]];n=np.cross(P[1]-P[0],P[2]-P[0]);nn=np.linalg.norm(n)
    sh=.55+.55*abs(float(n@Lv)/nn) if nn>0 else .8
    ok=ins&(z<zb[y0:y9+1,x0:x9+1])&(col[...,3]>.5)
    if not ok.any(): continue
    zb[y0:y9+1,x0:x9+1][ok]=z[ok]
    c=col[...,:3]*sh
    c=np.clip(c,0,1);img[y0:y9+1,x0:x9+1][ok]=np.dstack([c,np.ones(c.shape[:2])])[ok]
im=Image.fromarray((img*255).astype(np.uint8),'RGBA')
bb=im.getchannel('A').getbbox()
if not bb: sys.exit('empty')
an=((R/2-bb[0])/2,(R*.8-bb[1])/2)
im=im.crop(bb);im=im.resize((max(1,round(im.size[0]/2)),max(1,round(im.size[1]/2))),Image.LANCZOS)
im.save(f'/home/claude/map/game/img/{OUT}.png',optimize=True)
print(OUT,im.size,[round(v) for v in an],round(hm,1),len(tris))
