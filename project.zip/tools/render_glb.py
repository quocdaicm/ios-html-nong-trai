import numpy as np, json, struct, sys, math
from PIL import Image
fn,anim,nf=sys.argv[1],sys.argv[2],int(sys.argv[3]); out=sys.argv[4]
b=open(fn,'rb').read();o=12;js=None;BIN=None
while o<len(b):
    cl,ct=struct.unpack('<II',b[o:o+8]);ch=b[o+8:o+8+cl];o+=8+cl
    if ct==0x4E4F534A: js=json.loads(ch)
    else: BIN=ch
CT={5120:np.int8,5121:np.uint8,5122:np.int16,5123:np.uint16,5125:np.uint32,5126:np.float32};NT={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def acc(i):
    a=js['accessors'][i];bv=js['bufferViews'][a['bufferView']];dt=np.dtype(CT[a['componentType']]);n=NT[a['type']]
    off=bv.get('byteOffset',0)+a.get('byteOffset',0);st=bv.get('byteStride') or dt.itemsize*n
    r=np.ndarray((a['count'],n),dt,BIN,off,(st,dt.itemsize)).astype(np.float64)
    if a.get('normalized'): r/=np.iinfo(dt).max
    return r
nodes=js['nodes'];par={}
for i,n in enumerate(nodes):
    for c in n.get('children',[]): par[c]=i
def quat(q):
    x,y,z,w=q;return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
an=[a for a in js['animations'] if a['name']==anim][0]
chans=[]
for c in an['channels']:
    s=an['samplers'][c['sampler']];tin=acc(s['input'])[:,0];v=acc(s['output'])
    if s.get('interpolation')=='CUBICSPLINE': v=v[1::3]
    chans.append((c['target']['node'],c['target']['path'],tin,v))
dur=max(c[2][-1] for c in chans)
def samp(tin,v,t):
    if t<=tin[0]: return v[0]
    if t>=tin[-1]: return v[-1]
    k=np.searchsorted(tin,t)-1;u=(t-tin[k])/(tin[k+1]-tin[k]);a,c=v[k],v[k+1]
    if len(a)==4:
        if a@c<0: c=-c
        r=a*(1-u)+c*u;return r/np.linalg.norm(r)
    return a*(1-u)+c*u
def globals_(t):
    TRS={i:[np.array(n.get('translation',[0,0,0])),np.array(n.get('rotation',[0,0,0,1])),np.array(n.get('scale',[1,1,1]))] for i,n in enumerate(nodes)}
    for nd,p,tin,v in chans: TRS[nd][{'translation':0,'rotation':1,'scale':2}[p]]=samp(tin,v,t)
    G={}
    def g(i):
        if i in G: return G[i]
        n=nodes[i]
        if 'matrix' in n: M=np.array(n['matrix']).reshape(4,4).T
        else:
            M=np.eye(4);M[:3,:3]=quat(TRS[i][1])*TRS[i][2];M[:3,3]=TRS[i][0]
        G[i]=(g(par[i])@M) if i in par else M;return G[i]
    for i in range(len(nodes)): g(i)
    return G
a_=math.radians(float(sys.argv[5]) if len(sys.argv)>5 else 45);pc=math.radians(30)
YAWS=[45,135];CW=128;AX,AY=64,114;SC=0.6*100*2/1.0  # px per meter at 2x supersample
Lv=np.array([-.3,.7,.65]);Lv/=np.linalg.norm(Lv)
def lin2s(c): return np.clip(c,0,1)**(1/2.2)
def frame(t,yaw):
    G=globals_(t);a=math.radians(yaw);P=[];C=[];N=[];F=[]
    base=0
    for ni,n in enumerate(nodes):
        if 'mesh' not in n: continue
        for pr in js['meshes'][n['mesh']]['primitives']:
            pos=acc(pr['attributes']['POSITION']);nrm=acc(pr['attributes']['NORMAL']);idx=acc(pr['indices'])[:,0].astype(int)
            mat=js['materials'][pr['material']]['pbrMetallicRoughness'];bc=np.array(mat['baseColorFactor'][:3])
            col=np.tile(bc,(len(pos),1))
            if 'COLOR_0' in pr['attributes']: col=col*acc(pr['attributes']['COLOR_0'])[:,:3]
            hom=np.c_[pos,np.ones(len(pos))]
            if 'skin' in n:
                sk=js['skins'][n['skin']];ibm=acc(sk['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1)
                jm=np.array([G[j]@ibm[k] for k,j in enumerate(sk['joints'])]);jt=acc(pr['attributes']['JOINTS_0']).astype(int);w=acc(pr['attributes']['WEIGHTS_0'])
                Mv=sum(w[:,k,None,None]*jm[jt[:,k]] for k in range(4))
            else: Mv=np.tile(G[ni],(len(pos),1,1))
            wp=np.einsum('nij,nj->ni',Mv,hom)[:,:3];wn=np.einsum('nij,nj->ni',Mv[:,:3,:3],nrm)
            wn/=np.linalg.norm(wn,axis=1,keepdims=True)+1e-9
            P.append(wp);C.append(lin2s(col));N.append(wn);F.append(idx.reshape(-1,3)+base);base+=len(pos)
    P=np.vstack(P);C=np.vstack(C);N=np.vstack(N);F=np.vstack(F)
    x1=P[:,0]*math.cos(a)+P[:,2]*math.sin(a);z1=-P[:,0]*math.sin(a)+P[:,2]*math.cos(a)
    up=P[:,1]*math.cos(pc)-z1*math.sin(pc);dp=-P[:,1]*math.sin(pc)-z1*math.cos(pc)
    nx1=N[:,0]*math.cos(a)+N[:,2]*math.sin(a);nz1=-N[:,0]*math.sin(a)+N[:,2]*math.cos(a)
    nup=N[:,1]*math.cos(pc)-nz1*math.sin(pc);ntc=nz1*math.cos(pc)+N[:,1]*math.sin(pc)
    sh=.5+.6*np.maximum(0,nx1*Lv[0]+nup*Lv[1]+ntc*Lv[2]);Cs=np.clip(C*sh[:,None],0,1)
    R=2*CW;PX=x1*SC+AX*2;PY=-up*SC+AY*2
    img=np.zeros((R,R,4));zb=np.full((R,R),1e9)
    for t0,t1,t2 in F:
        xs=PX[[t0,t1,t2]];ys=PY[[t0,t1,t2]]
        x0,x9=int(max(0,np.floor(xs.min()))),int(min(R-1,np.ceil(xs.max())));y0,y9=int(max(0,np.floor(ys.min()))),int(min(R-1,np.ceil(ys.max())))
        if x9<x0 or y9<y0: continue
        den=(ys[1]-ys[2])*(xs[0]-xs[2])+(xs[2]-xs[1])*(ys[0]-ys[2])
        if abs(den)<1e-9: continue
        gx,gy=np.meshgrid(np.arange(x0,x9+1)+.5,np.arange(y0,y9+1)+.5)
        w0=((ys[1]-ys[2])*(gx-xs[2])+(xs[2]-xs[1])*(gy-ys[2]))/den;w1=((ys[2]-ys[0])*(gx-xs[2])+(xs[0]-xs[2])*(gy-ys[2]))/den;w2=1-w0-w1
        ins=(w0>=-1e-4)&(w1>=-1e-4)&(w2>=-1e-4)
        z=w0*dp[t0]+w1*dp[t1]+w2*dp[t2];ok=ins&(z<zb[y0:y9+1,x0:x9+1])
        if not ok.any(): continue
        zb[y0:y9+1,x0:x9+1][ok]=z[ok]
        c=w0[...,None]*Cs[t0]+w1[...,None]*Cs[t1]+w2[...,None]*Cs[t2]
        img[y0:y9+1,x0:x9+1][ok]=np.dstack([c,np.ones(c.shape[:2])])[ok]
    return Image.fromarray((img*255).astype(np.uint8),'RGBA').resize((CW,CW),Image.LANCZOS)
rows=[]
sheet=Image.new('RGBA',(CW*nf,CW*2))
for r,yaw in enumerate(YAWS):
    for k in range(nf):
        sheet.paste(frame(dur*k/nf if nf>1 else 0,yaw),(k*CW,r*CW))
sheet.save(out);print(out,'dur',round(dur,2),sheet.size)
