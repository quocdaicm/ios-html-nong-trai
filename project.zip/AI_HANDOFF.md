# AI_HANDOFF.md — Tài liệu bàn giao cho AI / dev làm tiếp

> Đọc file này TRƯỚC khi sửa bất cứ thứ gì. Cập nhật lại file này mỗi khi thay đổi kiến trúc.

## 1. Dự án là gì
Game **"Nông Trại Nhỏ"**: idle/tycoon nông trại, bản đồ isometric 24×24 ô, vẽ bằng Canvas 2D, chạy trong **một file `game/index.html`** (không build step, không thư viện ngoài). Được bọc thành **app iPhone** bằng WKWebView và build ra **IPA chưa ký bằng GitHub Actions** (người dùng sideload bằng Sideloadly/AltStore/TrollStore).

Hoàn cảnh người dùng (quan trọng): nói **tiếng Việt**, làm việc **hoàn toàn trên điện thoại** (không có máy tính/Xcode). Mọi thay đổi nên giao dưới dạng **file zip có đúng cấu trúc thư mục** để họ giải nén và upload lên GitHub bằng giao diện web. Giữ UI/text trong game bằng tiếng Việt.

## 2. Cấu trúc repo
```
game/                    <- ĐANG DÙNG: toàn bộ game
  index.html             1 file chứa HTML+CSS+JS (~20KB)
  img/                   sprite PNG (xem mục 6)
  CREDITS.txt            ghi nguồn mô hình 3D (CC BY 3.0) — PHẢI giữ
ios/                     <- ĐANG DÙNG: vỏ app iOS
  project.yml            XcodeGen spec (tên app "Nông Trại Nhỏ", bundle dev.xomnongtrai.game)
  icon-1024.png          icon app tự vẽ (không dùng icon của game gốc)
  XomNongTrai/           AppDelegate.swift, GameViewController.swift, Assets.xcassets
  web/                   (do workflow sinh ra, KHÔNG commit)
.github/workflows/ios.yml    <- ĐANG DÙNG: build IPA (macos-15)
tools/                   script Python dựng sprite từ mô hình 3D (mục 7)
AI_HANDOFF.md            file này
# --- LEGACY (không dùng cho bản iOS hiện tại) ---
public/ src/ browser/ config/ scripts/ server.mjs tests/ reference/ package*.json README.md REVIEW.md
.github/workflows/pages.yml
```
**Legacy** = bản web gốc "xom_nong_trai" (tái tạo client/asset của game nongtrai.jackle.dev). Nó chứa asset không phải của người dùng → **rủi ro bản quyền**, đã khuyên người dùng xóa hoặc để repo private. Đừng đưa lại asset/code đó vào `game/`. `pages.yml` có thể vẫn chạy khi push (build web gốc) — vô hại nhưng có thể xóa.

## 3. Pipeline build (`.github/workflows/ios.yml`)
Kích hoạt: `workflow_dispatch` hoặc push lên `main` đụng `ios/**`, `game/**`, workflow.
1. `cp -R game/. ios/web/` (web bundle nằm trong app)
2. `cp ios/icon-1024.png` → `AppIcon.appiconset/icon-1024.png`
3. `brew install xcodegen && xcodegen generate` (từ `ios/project.yml`; thư mục `web` được nạp là *folder reference* → giữ nguyên cấu trúc `img/...`)
4. `xcodebuild ... CODE_SIGNING_ALLOWED=NO` → đóng gói `Payload/*.app` thành `XomNongTrai.ipa` → upload artifact `XomNongTrai-ipa`.
Chưa từng chạy trên GitHub thật bởi AI (sandbox không có Xcode/mạng): **nếu build lỗi, đọc log Actions trước, sửa nhỏ.**

### 3b. Chế độ build từ `project.zip` (dành cho người dùng chỉ có điện thoại)
Workflow `.github/workflows/ios-from-zip.yml`: người dùng upload **1 file `project.zip`** (chứa `ios/`, `game/`, `tools/`, `AI_HANDOFF.md`) vào GỐC repo; Actions tự `unzip` vào `src/`, tìm `*/ios/project.yml`, chép `game/` → `ios/web/`, chép icon, XcodeGen, xcodebuild unsigned, xuất `XomNongTrai.ipa`. Chạy khi push `project.zip` hoặc bấm Run workflow. Khi cập nhật game: tạo `project.zip` mới cùng cấu trúc và upload đè. (`ios.yml` là chế độ build trực tiếp từ thư mục `game/` trong repo; dùng một trong hai.)

## 4. Vỏ iOS (`GameViewController.swift`)
- WKWebView nạp `app://localhost/index.html`. Scheme tùy chỉnh `app` do `LocalSchemeHandler` phục vụ file từ thư mục `web` trong bundle (có **hỗ trợ Range** cho audio, MIME đúng, fallback về index.html).
- `mediaTypesRequiringUserActionForPlayback = []`, `allowsInlineMediaPlayback = true`. Audio vẫn cần 1 chạm đầu tiên (game gọi `au()` ở pointerdown).
- Link http/https mở bằng Safari. Ẩn status bar & home indicator. localStorage hoạt động (dùng để lưu game).
- **BẪY:** `alert()/confirm()/prompt()` KHÔNG hoạt động (chưa cài `WKUIDelegate` panel) → trả về im lặng. Game dùng nút xác nhận 2 lần chạm / toast thay thế. Đừng dùng chúng.

## 5. Kiến trúc `game/index.html`
### Hằng số / hệ tọa độ
`N=24` (lưới N×N), `TW=64`, `TH=32` (ô kim cương 2:1). Ô `(x,y)`, chỉ số mảng `I(x,y)=y*N+x`.
Màn hình: `sx=(x-y)*TW/2*z+ox`, `sy=(x+y)*TH/2*z+oy` (đây là **đỉnh trên** của ô; tâm ô = `sc(x+.5,y+.5)`; hàm `sc()` nhận tọa độ thực).
Ngược lại (tap): `a=sy/(TH/2)`, `b=sx/(TW/2)`, `x=floor((a+b)/2)`, `y=floor((a-b)/2)` với `sx=(px-ox)/z`, `sy=(py-oy)/z`.
Hướng đi trên màn hình: `+x` = xuống-phải, `+y` = xuống-trái, `-x` = lên-trái, `-y` = lên-phải.
Vẽ theo **painter's algorithm**: duyệt chéo `s=x+y`, mỗi ô vẽ nền → cây/đồ vật/công trình/đường; sau đó vẽ động vật+xe+người+nhân vật đã sắp xếp theo `x+y`.

### State `S` (lưu localStorage key `xnt_map_v1`, tự lưu mỗi 5s + khi ẩn app)
`xu` (tiền), `u[]` (đã mở ô: 0/1), `b[]` (loại công trình theo chỉ số bảng `B`, -1 = trống), `l[]` (cấp), `snd` (âm thanh 0/1), `last` (timestamp để tính offline), `pl` (cây người chơi trồng: `{chỉSốÔ: [chỉSốSprite, timestampTrồng]}`), `ch` (`'co'|'cau'`), `px,py` (vị trí nhân vật).
Nếu đổi cấu trúc state: **tăng KEY** hoặc thêm migration (`S.x=S.x||default` như `S.pl`), đừng làm hỏng save cũ.

### Bảng `B` (công trình) — **chỉ được THÊM vào cuối** (save lưu theo chỉ số)
0 Ruộng lúa, 1 Chuồng gà (🐔), 2 Trại bò (🐄), 3 Vườn táo, 4 Nhà máy, **5 Đường** (`road`, logic riêng, hằng số `5` được hard-code trong `isR`, `syncV`, draw).

### Kinh tế
- Thu nhập/giây `cps()` = Σ `B[k].r * l` + 0.4 × số cây đã lớn.
- Mở ô: `40*1.12^(số ô đã mở-25)` (chỉ ô sát ô đã mở). Xây: `B.c*1.15^(số công trình cùng loại)`. Nâng cấp: `B.c*2*1.8^(cấp-1)`.
- Chạm công trình: thưởng `max(1, r*l*5)` + mở sheet nâng cấp.
- Offline: tối đa 8 giờ × cps khi mở lại.
- Nhân vật: trồng cây 5 xu → lớn sau 60s (thời gian thực, tính cả lúc offline) → thu hoạch `25+cps*10` rồi trồng lại; "Làm việc" trên công trình: `max(5, r*l*30)`, hồi 6s.

### Thực thể động
- `A` = động vật: gà/bò emoji theo chuồng (2 con/chuồng, tối đa 40) + `Wd` (9 con "hoang" dùng sprite: ngựa×2, chó, bulldog, mèo×2, thỏ×3) đi lang thang trong vùng đã mở. `sync()` dựng lại `A`.
- `Vh` = xe + người đi bộ chạy trên đồ thị ô đường (`pick()` chọn hướng kế, không quay đầu trừ ngõ cụt). `syncV()`: xe = min(6, đường/3), người = min(4, đường/4). Xe: bus, suv, van, peugeot-308; người: `man`.
- `PL` = nhân vật điều khiển (cần điều khiển ảo `#js` + nút hành động `#act`; hành động phụ thuộc ô đang đứng: trồng/thu hoạch/làm việc; chạm canvas để kéo/zoom/mở ô/xây).
- Camera: kéo 1 ngón = pan, 2 ngón = pinch zoom (0.35–2.5), tự bám theo nhân vật khi đang đi.

### Sprite (quan trọng)
- `DN=[[tên,chiềuCaoPx],...]` — **chỉ số cố định**: 0 birch, 1 bush, 2 coconutTree, 3 cypress, 4 hydrangea, 5 lavender-bush, 6 pansy, 7 peachBlossom, 8 pine, 9 roses-bush, 10 tree, 11 weepingWillow, 12 horse2, 13 dog, 14 cat, 15 rabbit, 16 bulldog, 17 siameseCat, 18 bench, 19 picnic_table, 20 dog-house, 21 gardenUmbrella. Mã trỏ tới các chỉ số này (`TR`,`FL`,`TRK`, `Wd`, `deco()`, tiếng kêu theo `a.spr`). Thêm cuối, đừng đổi thứ tự.
- Cây/đồ vật: ảnh đã cắt khung, neo = giữa-đáy; vẽ bằng `dsp()`.
- Xe/người `VK`: sprite `img/v_<tên>_<yaw>.png`, yaw 45=đi `+x`, 135=`-y`, 225=`-x`, 315=`+y`; mỗi sprite có **điểm neo** (gốc mô hình trên ảnh) trong `VK[tên].a[hướng]`, `f` = hệ số phóng. Nếu render lại sprite thì phải cập nhật neo (script in ra).
- Nhân vật `img/char_co.png`, `char_cau.png`: lưới ô 128×128, 6 cột × 6 hàng. Hàng 0/1 = đi (yaw45/135), 2/3 = cúi làm việc, 4/5 = đứng yên (chỉ cột 0). Neo (64,114). Hướng xuống-trái và lên-trái = **lật ngang** hướng xuống-phải / lên-phải.

### Âm thanh
Hoàn toàn tổng hợp bằng WebAudio (không file âm thanh): nhạc nền pentatonic ngẫu nhiên (`au()`), `SF` = coin/build/no/cluck/moo/neigh/bark/meow/horn. Nút 🔊 bật/tắt (master gain). AudioContext tạo ở lần chạm đầu.

## 6. Giấy phép / nguồn gốc asset
- Cây, hoa, động vật, đồ vật, xe, người mannequin: render từ mô hình thư viện **Sweet Home 3D** trong file `CityBuilder_SaoLuu_PhanLoai.zip` của người dùng, giấy phép **CC BY 3.0** (và/hoặc Free Art License) → bắt buộc ghi nguồn: giữ `game/CREDITS.txt`; nếu phát hành App Store thì thêm màn hình "Ghi công".
- Nhân vật cô bé/cậu bé: `co_be.glb`, `cau_be.glb` do người dùng cung cấp (có dấu hiệu từ công cụ tạo avatar, không có texture; dùng màu vật liệu). **Chưa kiểm tra giấy phép** — nhắc người dùng nếu định phát hành.
- Tuyệt đối không dùng lại asset/code của game gốc nongtrai.jackle.dev.

## 7. Dựng sprite (`tools/`) — chạy trên Python 3 + numpy + Pillow (KHÔNG cần GPU/Blender)
Rasterizer tự viết bằng numpy (z-buffer, flat/Gouraud shading, ánh sáng cố định theo khung nhìn). Camera: ortho, yaw (xoay quanh trục Y), pitch 30°. Đường dẫn xuất đang hard-code `/home/claude/map/game/img/` → sửa khi dùng.
- `render_obj_fit.py <tên>`: OBJ+MTL(+texture, alpha test) → 1 sprite 192px đã cắt khung, tự chuẩn hóa kích thước (dùng cho cây/hoa/động vật/đồ vật; thư mục model: `Models/<tên>/`).
- `render_obj_fixed.py <tên> <yaw> <outName> <pxPerCm>`: như trên nhưng **tỷ lệ cố định** + in ra điểm neo (dùng cho xe/người; chạy 4 yaw 45/135/225/315). Ví dụ: `python render_obj_fixed.py bus 45 v_bus_45 0.12`.
- `render_glb.py <file.glb> <Animation> <số_khung> <out.png>`: glTF **có skinning + animation** (đọc accessor, TRS, skin matrices, vertex color × baseColorFactor, chuyển linear→sRGB). Xuất 2 hàng (yaw 45 và 135) × N khung, ô 128×128. Đã dùng: `Walk 6`, `Bow 6`, `Idle 1`, rồi ghép thành `char_*.png` (xếp hàng như mục 5). Các animation sẵn có trong GLB chưa dùng: Wave, Cheer, JumpClap, Spin, Run, Talk, KpopIdle…
Máy dựng chỉ có 1 CPU: ~2 giây/khung.

## 8. Quy ước & lưu ý khi sửa
- Giữ **một file** `index.html`, không thêm framework/CDN (app chạy offline). Ảnh qua đường dẫn tương đối `img/...`.
- Mobile-first: dùng Pointer Events; tôn trọng `env(safe-area-inset-*)`; `touch-action:none`.
- Canvas vẽ mỗi frame (`requestAnimationFrame`); cẩn thận hiệu năng (đang cull ô ngoài màn hình).
- Typographic: text tiếng Việt, tránh dấu nháy thẳng trong chuỗi hiển thị.
- Mọi thay đổi gameplay nên giữ tương thích save (xem mục 5).
- Kiểm tra cú pháp nhanh: trích `<script>` rồi `new Function(code)` bằng Node. Test cục bộ: `cd game && python3 -m http.server` rồi mở trình duyệt (đường dẫn `img/...` chạy được).
- Giao việc cho người dùng dưới dạng zip theo cấu trúc repo; ghi rõ file nào đè lên file nào.

## 9. Trạng thái & việc có thể làm tiếp
Đã làm: bản đồ kéo/zoom, mở ô, 5 công trình + nâng cấp, đường + xe + người đi bộ, động vật lang thang, cây hoa rải khắp bản đồ, âm thanh tổng hợp, nhân vật điều khiển (đi/trồng/thu hoạch/làm việc), offline earnings, build IPA.
**Chưa kiểm chứng trên thiết bị thật** (sandbox không có Xcode/trình duyệt): cân bằng kinh tế, hiệu năng iPhone cũ, workflow Actions chạy lần đầu.
Ý tưởng: thêm công trình/cây trồng khác, nhiệm vụ & thành tựu, mùa/thời tiết, đèn giao thông/va chạm xe, dùng thêm animation (Wave/Cheer) khi thu hoạch, nhân vật thứ hai đi cùng, mở rộng bản đồ, màn hình "Ghi công", dọn repo (xóa phần legacy), thêm bản nhạc.
