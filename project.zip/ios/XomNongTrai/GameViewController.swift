import UIKit
import WebKit
import UniformTypeIdentifiers

/// Serves files from the bundled "web" folder at app://localhost/ (with Range support for audio).
final class LocalSchemeHandler: NSObject, WKURLSchemeHandler {
    private let root: URL
    init(root: URL) { self.root = root }

    private func mime(for url: URL) -> String {
        switch url.pathExtension.lowercased() {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json", "webmanifest": return "application/json; charset=utf-8"
        case "webp": return "image/webp"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "svg": return "image/svg+xml"
        case "mp3": return "audio/mpeg"
        case "woff2": return "font/woff2"
        case "glb": return "model/gltf-binary"
        default:
            return UTType(filenameExtension: url.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
        }
    }

    func webView(_ webView: WKWebView, start task: WKURLSchemeTask) {
        guard let reqURL = task.request.url else { task.didFailWithError(URLError(.badURL)); return }
        var path = reqURL.path.removingPercentEncoding ?? reqURL.path
        if path.isEmpty || path == "/" { path = "/index.html" }
        if path.contains("..") { task.didFailWithError(URLError(.badURL)); return }
        var fileURL = root.appendingPathComponent(String(path.dropFirst()))
        if !FileManager.default.fileExists(atPath: fileURL.path) {
            // SPA fallback
            fileURL = root.appendingPathComponent("index.html")
        }
        guard let data = try? Data(contentsOf: fileURL, options: .mappedIfSafe) else {
            let r = HTTPURLResponse(url: reqURL, statusCode: 404, httpVersion: "HTTP/1.1", headerFields: nil)!
            task.didReceive(r); task.didFinish(); return
        }
        var headers: [String: String] = [
            "Content-Type": mime(for: fileURL),
            "Accept-Ranges": "bytes",
            "Cache-Control": "no-cache"
        ]
        var status = 200
        var body = data
        if let range = task.request.value(forHTTPHeaderField: "Range"), range.hasPrefix("bytes=") {
            let parts = range.dropFirst(6).split(separator: "-", omittingEmptySubsequences: false)
            let total = data.count
            var start = Int(parts.first ?? "") ?? 0
            var end = parts.count > 1 ? (Int(parts[1]) ?? total - 1) : total - 1
            if parts.first == "" { start = max(0, total - (Int(parts[1]) ?? 0)); end = total - 1 }
            end = min(end, total - 1)
            if start <= end {
                body = data.subdata(in: start..<(end + 1))
                headers["Content-Range"] = "bytes \(start)-\(end)/\(total)"
                status = 206
            }
        }
        headers["Content-Length"] = String(body.count)
        let resp = HTTPURLResponse(url: reqURL, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers)!
        task.didReceive(resp)
        task.didReceive(body)
        task.didFinish()
    }

    func webView(_ webView: WKWebView, stop task: WKURLSchemeTask) {}
}

final class GameViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private var webView: WKWebView!

    override func loadView() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.websiteDataStore = .default()
        let web = Bundle.main.resourceURL!.appendingPathComponent("web")
        config.setURLSchemeHandler(LocalSchemeHandler(root: web), forURLScheme: "app")
        let wv = WKWebView(frame: .zero, configuration: config)
        wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.scrollView.bounces = false
        wv.scrollView.contentInsetAdjustmentBehavior = .never
        wv.isOpaque = false
        wv.backgroundColor = UIColor(red: 0.2, green: 0.5, blue: 0.16, alpha: 1)
        if #available(iOS 16.4, *) { wv.isInspectable = true }
        webView = wv
        view = wv
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        webView.load(URLRequest(url: URL(string: "app://localhost/index.html")!))
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }

    // Open external links in Safari
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let url = action.request.url, let scheme = url.scheme, scheme == "http" || scheme == "https" {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url { UIApplication.shared.open(url) }
        return nil
    }
}
